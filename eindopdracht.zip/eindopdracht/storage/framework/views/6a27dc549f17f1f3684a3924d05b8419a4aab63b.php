<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="full-right">
                <h2>Beheer vakken</h2>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th>id</th>
            <th>Naam</th>
            <th>Omschrijving</th>
            <th>Coördinator</th>
            <th>
                <a href="<?php echo e(route('course.create')); ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-plus"></i>
                </a>
            </th>
        </tr>
        <?php $no=1; ?>
        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->omschrijving); ?></td>
                <td><?php echo e($value->coordinator); ?></td>
                <td>
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('course.show', $value->id)); ?>">
                        <i class="fas fa-th-large text-light"></i>
                    </a>
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('course.edit', $value->id)); ?>">
                        <i class="fas fa-pencil-alt"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/course/index.blade.php ENDPATH**/ ?>