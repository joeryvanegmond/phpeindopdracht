<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center mt-5">
        <div class="col-lg-12 d-flex">
            <div class="col-2">
                <div class="pull-left">
                    <a href="<?php echo e(route('course.index')); ?>">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                </div>
            </div>

            <div class="col-8">
                <h2>Bewerken</h2>
                    <?php echo Form::model($course, ['route'=>['course.update', $course->id], 'method'=>'PATCH']); ?>

                <div class="form-group">
                    <?php echo e(Form::label('name', 'Vak')); ?>

                    <?php echo e(Form::text('name', $course->name, ['class' => 'form-control', 'placeholder' => 'Naam'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('omschrijving', 'Omschrijving')); ?>

                    <?php echo e(Form::textarea('omschrijving', $course->omschrijving, ['class' => 'form-control', 'placeholder' => 'Omschrijving'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('coordinator', 'Coordinator')); ?>

                    <?php echo Form::select('coordinator', $teachers, $course->coordinator, ['class'=>'form-control', 'placeholder'=>'Kies coördinator']); ?>

                </div>
                <?php echo Form::submit('Wijzigen', ['class' => 'btn btn-success'] ); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/course/edit.blade.php ENDPATH**/ ?>