<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center mt-5">
        <div class="col-lg-12 d-flex">
            <div class="col-2">
                <div class="pull-left">
                    <a href="<?php echo e(route('course.index')); ?>">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                </div>
            </div>

            <div class="col-8">
                <h2 class="col-4">Vak details</h2>
                <div class="form-group d-flex">
                    <div class="font-weight-bold col-2">Naam: </div>
                    <div class="col-6"><?php echo e($course->name); ?></div>
                </div>

                <div class="form-group d-flex">
                    <div class="font-weight-bold col-2">Omschrijving: </div>
                    <div class="col-6"><?php echo e($course->omschrijving); ?></div>
                </div>

                <div class="form-group d-flex">
                    <div class="font-weight-bold col-2">Coördinator: </div>
                    <div class="col-6">
                        <?php echo e($teacher->name); ?>

                        <?php echo e($teacher->infix); ?>

                        <?php echo e($teacher->lastname); ?>

                    </div>
            </div>

            </div>
            </div>
        </div>








































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/course/show.blade.php ENDPATH**/ ?>