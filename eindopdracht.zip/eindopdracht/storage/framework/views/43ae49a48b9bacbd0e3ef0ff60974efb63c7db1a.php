<div class="row">
    <div class="col-sm-2">
        <?php echo form::label('name', 'Name'); ?>

    </div>
    <div class="col-sm-10">
        <div class="form-group" {$errors->has('name') ? 'has-error' : ""}>
            <?php echo Form::text('name', null, ['class' =>'form-control', 'id'=>'name', 'placeholder'=>'Name course...']); ?>

            <?php echo $error->first('name', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-2">
        <?php echo form::label('omschrijving', 'Omschrijving'); ?>

    </div>
    <div class="col-sm-10">
        <div class="form-group" <?php echo e($errors->has('name') ? 'has-error' : ""); ?>>
            <?php echo Form::text('omschrijving', null, ['class' =>'form-control', 'id'=>'omschrijving', 'placeholder'=>'Omschrijving course...']); ?>

            <?php echo $error->first('omschrijving', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
</div>

<div class="form-group">
    { Form::button(isset($model)? 'Update' : 'save', ['class'=>'btn btn-success', 'type'=>'submit']) }
</div>
<?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/course/form_master.blade.php ENDPATH**/ ?>