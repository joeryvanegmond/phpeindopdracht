<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center mt-5">
        <div class="col-lg-12 d-flex">
            <div class="col-2">
                <div class="pull-left">
                    <a href="<?php echo e(route('teacher.index')); ?>">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                </div>
            </div>

            <div class="col-8">
                <h2>Aanmaken</h2>
                <?php echo Form::open(['route'=>'teacher.store', 'method'=>'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('name', 'Voornaam')); ?>

                        <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Voornaam'])); ?>

                    </div>

                    <div class="form-group">
                        <?php echo e(Form::label('infix', 'Tussenvoegsel')); ?>

                        <?php echo e(Form::text('infix', '', ['class' => 'form-control', 'placeholder' => 'Tussenvoegsel'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('lastname', 'Achternaam')); ?>

                        <?php echo e(Form::text('lastname', '', ['class' => 'form-control', 'placeholder' => 'Achternaam'])); ?>

                    </div>
                    <div class="form-group d-flex flex-column mt-4">
                        <div>
                        <div class="h5">Welk(e) vak(ken) geeft de docent?</div>
                        </div>
                            <?php if($courses->count() > 0): ?>
                               <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <?php echo Form::checkbox('course_array[]', $value->id); ?>

                                        <?php echo e(Form::label('', $value->name)); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>geen vakken beschikbaar</p>
                        <?php endif; ?>
                    </div>
                <?php echo Form::submit('Toevoegen', ['class' => 'btn btn-success'] ); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/teacher/create.blade.php ENDPATH**/ ?>