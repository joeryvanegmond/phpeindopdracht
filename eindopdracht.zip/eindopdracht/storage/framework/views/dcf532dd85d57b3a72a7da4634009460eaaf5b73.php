<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center mt-5">
        <div class="col-lg-12">
            <div class="full-right">
                <h2>Beheer docenten</h2>
            </div>
        </div>
    </div>

    <table class="table table-bordered">
        <tr>
            <th>Nr</th>
            <th>Naam</th>
            <th width="30">
                <a href="<?php echo e(route('teacher.create')); ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-plus"></i>
                </a>
            </th>
        </tr>
        <?php $no=1; ?>
        <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td>
                    <?php echo e($value->name); ?>

                    <?php echo e($value->infix); ?>

                    <?php echo e($value->lastname); ?>

                </td>
                <td class="d-flex">
                    <a class="btn btn-info btn-sm mr-2" href="<?php echo e(route('teacher.show', $value->id)); ?>">
                        <i class="fas fa-eye text-light"></i>
                    </a>
                    <a class="btn btn-primary btn-sm mr-2" href="<?php echo e(route('teacher.edit', $value->id)); ?>">
                        <i class="fas fa-pencil-alt"></i>
                    </a>
                    <?php echo Form::open(['method'=>'DELETE','route'=>['teacher.destroy', $value->id]]); ?>

                    <button type="submit" class="btn btn-danger btn-sm">
                        <i class="fas fa-trash"></i>
                    </button>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/teacher/index.blade.php ENDPATH**/ ?>