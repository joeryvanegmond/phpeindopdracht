<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center mt-5">
        <div class="col-lg-12 d-flex">
            <div class="col-2">
                <div class="pull-left">
                    <a href="<?php echo e(route('teacher.index')); ?>">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                </div>
            </div>

            <div class="col-8">
                <h2>Aanmaken</h2>
                <?php echo Form::model($teacher, ['route'=>['teacher.update', $teacher->id], 'method'=>'PATCH']); ?>

                <div class="form-group">
                    <?php echo e(Form::label('name', 'Voornaam')); ?>

                    <?php echo e(Form::text('name', $teacher->name, ['class' => 'form-control', 'placeholder' => 'Voornaam'])); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('infix', 'Tussenvoegsel')); ?>

                    <?php echo e(Form::text('infix', $teacher->infix, ['class' => 'form-control', 'placeholder' => 'Tussenvoegsel'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('lastname', 'Achternaam')); ?>

                    <?php echo e(Form::text('lastname', $teacher->lastname, ['class' => 'form-control', 'placeholder' => 'Achternaam'])); ?>

                </div>
                <div class="form-group d-flex flex-column mt-4">
                    <div>
                        <div class="h5">Welk(e) vak(ken) geeft de docent?</div>
                    </div>

                    <?php if($courses->count() > 0): ?>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <?php if($teacher->courses()->find($value->id)): ?>
                                    <?php echo Form::checkbox('course_array[]', $value->id, true); ?>

                                    <?php echo e(Form::label('', $value->name)); ?>

                                <?php else: ?>
                                    <?php echo Form::checkbox('course_array[]', $value->id, false); ?>

                                    <?php echo e(Form::label('', $value->name)); ?>

                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>geen vakken beschikbaar</p>
                    <?php endif; ?>
                </div>
                <?php echo Form::submit('Wijzigen', ['class' => 'btn btn-success'] ); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/teacher/edit.blade.php ENDPATH**/ ?>