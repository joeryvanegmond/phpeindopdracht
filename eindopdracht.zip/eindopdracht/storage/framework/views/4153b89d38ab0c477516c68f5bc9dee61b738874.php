<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <?php echo Form::open(['route'=>'course.store', 'method'=>'POST']); ?>

                <div class="form-group">
                    <?php echo e(Form::label('name', 'Vak')); ?>

                    <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Naam'])); ?>

                    <?php echo e(Form::label('omschrijving', 'Omschrijving')); ?>

                    <?php echo e(Form::textarea('omschrijving', '', ['class' => 'form-control', 'placeholder' => 'Omschrijving'])); ?>

                    <?php echo e(Form::label('coordinator', 'Coordinator')); ?>

                    <?php echo e(Form::select('coordinator', $teachers)); ?>

                </div>
            <?php echo Form::submit('Toevoegen', ['class' => 'btn btn-success'] ); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/joeryvanegmond/Documents/Avans/leerjaar_2/BLOK_7/php/phpeindopdracht/eindopdracht/resources/views/course/create.blade.php ENDPATH**/ ?>